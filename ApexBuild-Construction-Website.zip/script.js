/**
 * APEXBUILD CONSTRUCTION - INTERACTIVE FRONTEND ARCHITECTURE
 * Modules:
 * 1. Navigation & Scroll Spy
 * 2. Portfolio Gallery Data, Filtering & Lightbox Modal
 * 3. Client Ratings & Dynamic Review Submission
 * 4. Interactive Cost Estimator
 * 5. Project Inquiry Form Validation & Submission
 */

document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    initPortfolioGallery();
    initReviewsSystem();
    initCostEstimator();
    initInquiryForm();
});

/* ==========================================================================
   1. NAVIGATION & MOBILE MENU
   ========================================================================== */
function initNavigation() {
    const mobileToggle = document.getElementById('mobileToggle');
    const navMenu = document.getElementById('navMenu');
    const navLinks = document.querySelectorAll('.nav-link');

    mobileToggle.addEventListener('click', () => {
        navMenu.classList.toggle('open');
        const icon = mobileToggle.querySelector('i');
        icon.classList.toggle('fa-bars');
        icon.classList.toggle('fa-xmark');
    });

    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            navMenu.classList.remove('open');
            navLinks.forEach(l => l.classList.remove('active'));
            link.classList.add('active');
        });
    });
}

/* ==========================================================================
   2. PORTFOLIO GALLERY & LIGHTBOX
   ========================================================================== */
const portfolioProjects = [
    {
        id: 1,
        title: "The Meridian Corporate Tower",
        category: "commercial",
        location: "Downtown Austin, TX",
        area: "145,000 sq.ft",
        completion: "2025",
        image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=900&q=80",
        description: "A 18-story LEED Gold certified glass-and-steel commercial headquarters featuring post-tensioned concrete slabs and triple-glazed curtain walls."
    },
    {
        id: 2,
        title: "Oakridge Cantilever Villa",
        category: "residential",
        location: "Westlake Hills, TX",
        area: "8,400 sq.ft",
        completion: "2026",
        image: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=900&q=80",
        description: "Custom architectural hillside estate built with structural steel cantilevers, architectural board-formed concrete, and infinity edge pool engineering."
    },
    {
        id: 3,
        title: "Titan Logistics & Cold Storage Hub",
        category: "industrial",
        location: "San Antonio, TX",
        area: "310,000 sq.ft",
        completion: "2025",
        image: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=900&q=80",
        description: "High-bay tilt-wall concrete distribution facility featuring 42-foot clear heights, super-flat laser-screeded floors, and 40 automated loading docks."
    },
    {
        id: 4,
        title: "Foundry District Heritage Lofts",
        category: "renovation",
        location: "Dallas, TX",
        area: "62,000 sq.ft",
        completion: "2024",
        image: "https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=900&q=80",
        description: "Adaptive reuse and seismic structural retrofitting of a 1920s brick manufacturing warehouse into 48 luxury mixed-use residential lofts."
    },
    {
        id: 5,
        title: "Solstice Medical & Biotech Plaza",
        category: "commercial",
        location: "Houston, TX",
        area: "95,000 sq.ft",
        completion: "2026",
        image: "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&w=900&q=80",
        description: "Outpatient surgical and diagnostic center built with vibration-isolated floors, medical gas infrastructure, and redundant backup power systems."
    },
    {
        id: 6,
        title: "Clearwater Modern Farmhouse Estate",
        category: "residential",
        location: "Fredericksburg, TX",
        area: "5,600 sq.ft",
        completion: "2025",
        image: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=900&q=80",
        description: "Exposed heavy timber trusses, locally quarried limestone masonry, and net-zero solar integration across a 12-acre ranch property."
    }
];

function initPortfolioGallery() {
    const grid = document.getElementById('portfolioGrid');
    const filterBtns = document.querySelectorAll('.filter-btn');
    const modal = document.getElementById('projectModal');
    const modalBody = document.getElementById('projectModalBody');
    const closeModal = document.getElementById('closeProjectModal');

    function renderProjects(filter = 'all') {
        const filtered = filter === 'all'
            ? portfolioProjects
            : portfolioProjects.filter(p => p.category === filter);

        grid.innerHTML = filtered.map(project => `
            <article class="project-card" data-id="${project.id}">
                <div class="project-img-wrap">
                    <span class="project-category">${project.category}</span>
                    <img src="${project.image}" alt="${project.title}" loading="lazy">
                </div>
                <div class="project-info">
                    <h3>${project.title}</h3>
                    <p>${project.description.substring(0, 95)}...</p>
                    <div class="project-meta">
                        <span><i class="fa-solid fa-location-dot"></i> ${project.location}</span>
                        <span><i class="fa-solid fa-ruler-combined"></i> ${project.area}</span>
                    </div>
                </div>
            </article>
        `).join('');

        // Attach lightbox listeners
        document.querySelectorAll('.project-card').forEach(card => {
            card.addEventListener('click', () => {
                const projectId = Number(card.dataset.id);
                const item = portfolioProjects.find(p => p.id === projectId);
                if (item) openProjectModal(item);
            });
        });
    }

    function openProjectModal(project) {
        modalBody.innerHTML = `
            <img src="${project.image}" alt="${project.title}" class="modal-project-img">
            <span class="section-subtitle">${project.category.toUpperCase()} PROJECT</span>
            <h2>${project.title}</h2>
            <div class="modal-specs">
                <div><strong>Location:</strong><br>${project.location}</div>
                <div><strong>Total Area:</strong><br>${project.area}</div>
                <div><strong>Completed:</strong><br>${project.completion}</div>
            </div>
            <p>${project.description}</p>
            <div style="margin-top: 24px;">
                <a href="#inquiry" class="btn btn-primary" onclick="document.getElementById('projectModal').classList.remove('open')">
                    Request Similar Project Quote
                </a>
            </div>
        `;
        modal.classList.add('open');
    }

    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            renderProjects(btn.dataset.filter);
        });
    });

    closeModal.addEventListener('click', () => modal.classList.remove('open'));
    modal.addEventListener('click', (e) => {
        if (e.target === modal) modal.classList.remove('open');
    });

    renderProjects();
}

/* ==========================================================================
   3. RATINGS & DYNAMIC CLIENT REVIEWS
   ========================================================================== */
const initialReviews = [
    {
        name: "Marcus Holloway",
        project: "Commercial Office Complex",
        rating: 5,
        date: "October 2026",
        comment: "ApexBuild delivered our 45,000 sq.ft headquarters two weeks ahead of schedule and 3% under the initial GMP estimate. Their site superintendents are top-tier."
    },
    {
        name: "Elena Rostova",
        project: "Custom Hillside Residence",
        rating: 5,
        date: "August 2026",
        comment: "Complex steel and concrete cantilever work requires true engineering discipline. Communication was transparent every single week from foundation pour to final walkthrough."
    },
    {
        name: "David Chen, VP Operations",
        project: "Industrial Warehouse Expansion",
        rating: 5,
        date: "June 2026",
        comment: "Zero safety incidents across 9 months of heavy structural steel erection. Their BIM coordination prevented costly utility clashes before construction even started."
    }
];

function initReviewsSystem() {
    const reviewsGrid = document.getElementById('reviewsGrid');
    const reviewModal = document.getElementById('reviewModal');
    const openBtn = document.getElementById('openReviewModalBtn');
    const closeBtn = document.getElementById('closeReviewModal');
    const reviewForm = document.getElementById('newReviewForm');
    const starIcons = document.querySelectorAll('#starPicker i');
    const ratingInput = document.getElementById('reviewRatingValue');

    function renderReviews() {
        reviewsGrid.innerHTML = initialReviews.map(rev => `
            <div class="review-card">
                <div class="review-header">
                    <div class="reviewer-meta">
                        <h4>${rev.name}</h4>
                        <span>${rev.project} • ${rev.date}</span>
                    </div>
                    <div class="review-stars">
                        ${'<i class="fa-solid fa-star"></i>'.repeat(rev.rating)}
                    </div>
                </div>
                <p class="review-body">"${rev.comment}"</p>
            </div>
        `).join('');
    }

    // Star Rating Picker Interaction
    starIcons.forEach(star => {
        star.addEventListener('click', () => {
            const val = Number(star.dataset.value);
            ratingInput.value = val;
            starIcons.forEach(s => {
                s.classList.toggle('active', Number(s.dataset.value) <= val);
            });
        });
    });

    openBtn.addEventListener('click', () => reviewModal.classList.add('open'));
    closeBtn.addEventListener('click', () => reviewModal.classList.remove('open'));
    reviewModal.addEventListener('click', (e) => {
        if (e.target === reviewModal) reviewModal.classList.remove('open');
    });

    reviewForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const newEntry = {
            name: document.getElementById('reviewerName').value.trim(),
            project: document.getElementById('reviewerProject').value.trim(),
            rating: Number(ratingInput.value),
            date: "Just Now",
            comment: document.getElementById('reviewText').value.trim()
        };

        initialReviews.unshift(newEntry);
        const countEl = document.getElementById('totalReviewsCount');
        countEl.textContent = Number(countEl.textContent) + 1;

        renderReviews();
        reviewForm.reset();
        reviewModal.classList.remove('open');
    });

    renderReviews();
}

/* ==========================================================================
   4. INSTANT CONSTRUCTION COST ESTIMATOR
   ========================================================================== */
function initCostEstimator() {
    const typeSelect = document.getElementById('calcType');
    const areaSlider = document.getElementById('calcArea');
    const areaDisplay = document.getElementById('areaValue');
    const finishSelect = document.getElementById('calcFinish');
    const output = document.getElementById('estimateOutput');

    function updateEstimate() {
        const ratePerSqFt = Number(typeSelect.value);
        const sqFt = Number(areaSlider.value);
        const multiplier = Number(finishSelect.value);

        areaDisplay.textContent = sqFt.toLocaleString();

        const baseEstimate = ratePerSqFt * sqFt * multiplier;
        const lowRange = Math.round(baseEstimate * 0.95);
        const highRange = Math.round(baseEstimate * 1.05);

        output.textContent = `$${lowRange.toLocaleString()} – $${highRange.toLocaleString()}`;
    }

    typeSelect.addEventListener('change', updateEstimate);
    areaSlider.addEventListener('input', updateEstimate);
    finishSelect.addEventListener('change', updateEstimate);

    updateEstimate();
}

/* ==========================================================================
   5. PROJECT INQUIRY FORM VALIDATION & SUBMISSION
   ========================================================================== */
function initInquiryForm() {
    const form = document.getElementById('inquiryForm');
    const feedback = document.getElementById('formFeedback');

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        feedback.className = 'form-feedback';
        feedback.textContent = '';

        const fullName = document.getElementById('fullName').value.trim();
        const email = document.getElementById('email').value.trim();
        const phone = document.getElementById('phone').value.trim();
        const projectType = document.getElementById('projectType').value;
        const budget = document.getElementById('budget').value;
        const location = document.getElementById('location').value.trim();
        const details = document.getElementById('details').value.trim();

        const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

        if (!fullName || !emailValid || !phone || !projectType || !budget || !location || !details) {
            feedback.classList.add('error');
            feedback.textContent = 'Please complete all required fields (*) with a valid email address.';
            return;
        }

        // Simulate successful submission (ready to hook into REST API / Formspree / EmailJS)
        feedback.classList.add('success');
        feedback.innerHTML = `<i class="fa-solid fa-circle-check"></i> Thank you, <strong>${fullName}</strong>! Your ${projectType} inquiry for <strong>${location}</strong> has been assigned Reference #APX-${Math.floor(1000 + Math.random() * 9000)}. Our estimating team will contact you within 24 hours.`;
        form.reset();
    });
}
